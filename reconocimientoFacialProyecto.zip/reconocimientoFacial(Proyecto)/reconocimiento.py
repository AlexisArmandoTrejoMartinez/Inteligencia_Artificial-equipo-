import cv2
import os
import paho.mqtt.publish as publish
import time
dataPath = 'C:/Users/Lenovo/Documents/reconocimientoFacial/dataset' #

imagePaths = os.listdir(dataPath)
print('imagePaths=',imagePaths)

face_recognizer = cv2.face.LBPHFaceRecognizer_create()

face_recognizer.read('modeloLBPHFace.xml')

#cap = cv2.VideoCapture(0,cv2.CAP_DSHOW)
#SE CARGA EL VIDEO A ANALIZAR EN LA VARIABLE cap
cap = cv2.VideoCapture('Prueba/Alex.mp4')
#SE CARGA EL CALSIFICADOR DE EL CUAL ES UNA NEURONA PRE-ENTRENADA
faceClassif = cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')


#INICIA EL PROCESO DE LECTURA DEL VIDEO PARA EL PROCESAMIENTO
while True:
	ret,frame = cap.read()
	if ret == False: break
	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
	auxFrame = gray.copy()

	faces = faceClassif.detectMultiScale(gray,1.3,5)
	i=False
	st=0
	for (x,y,w,h) in faces:
		rostro = auxFrame[y:y+h,x:x+w]
		rostro = cv2.resize(rostro,(150,150),interpolation= cv2.INTER_CUBIC)
		result = face_recognizer.predict(rostro)
		cv2.putText(frame,'{}'.format(result),(x,y-5),1,1.3,(255,255,0),1,cv2.LINE_AA)
		
		# SI LOS VALORES INDICADOS EN LA IMAGEN SON MENORES A 70 COMIENZA LA RUTINA DE LECTURA DE LA IMAGEN Y EXTRAE
		#DEL DIRECTORIO EL DATASET LAS IMAGENES CORRESPONDIENTES A DICHO ROSTRO PARA ANALIZAR Y DE LOS NOMBRES DEL 
		#DIRECTORIO COLOCARA EL NOMBRE CORRESPONDIENTE DEL ROSTRO
		if result[1] < 70 and i==False:
			cv2.putText(frame,'{}'.format(imagePaths[result[0]]),(x,y-25),2,1.1,(0,255,0),1,cv2.LINE_AA)
			cv2.rectangle(frame, (x,y),(x+w,y+h),(0,255,0),2)
			st=1
		#EN CASO QUE LA CONDICION SEA FALSA MARCARA COMO DESCONOCIDO 
		else:
			cv2.putText(frame,'Desconocido',(x,y-20),2,0.8,(0,0,255),1,cv2.LINE_AA)
			cv2.rectangle(frame, (x,y),(x+w,y+h),(0,0,255),2)
			st=0
#GUARDA EL VALOR ULTIMO EN UNA VARIABLE BOOLEANA PARA SABER CAUL FUE EL ULTIMO VALOR OBTENIDO 
		i=(result[1] < 70)
		

	cv2.imshow('frame',frame)
	k = cv2.waitKey(1)
	if k == 27:
		break
"""
	SE AÑADIO PARA ESTA PARTE UNA MAQUINA DE ESTADOS PARA QUE SE PUDIERA COMUNICAR EL SISTEMA CON ARDUINO
	Y QUE ENVIARA LOS VALORES DE FORMA MENOS SATURADA PERMITIENDO A NODEMCU PROCESAR ESTOS DATOS E INTERPRETARLOS COMO SALIDAS
	A  LOS LED 
"""

if i==True:
		publish.single("hola", "1", hostname="192.168.0.2")
else:
		publish.single("hola", "0", hostname="192.168.0.2")

cap.release()
cv2.destroyAllWindows()